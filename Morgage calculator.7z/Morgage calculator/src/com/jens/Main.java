package com.jens;

import java.text.NumberFormat;
import java.util.Scanner;

public class Main {
    static final byte MONTHS_IN_A_YEAR = 12 ;
    static final byte PERCENT = 100 ;
    private static double getInput(String prompt, int min , int max) {
        Scanner scan = new Scanner(System.in);
        double input;
        while (true) {
            System.out.print(prompt + ": ");
            input = scan.nextDouble();
            if (input >= min && input <= max)
                break;
            System.out.println("Please enter a value between " + min + " and " + max + " for " + prompt);
        }
        return input;
    }

    private static void displayMortgage(int principle, float annualRate, byte years) {
        System.out.println("Mortgage:");
        System.out.println("---------");
        System.out.println(NumberFormat.getCurrencyInstance().format(calcMortgage(principle, annualRate, years)));
    }

    private static double calcMortgage(int principle, float annualRate, byte years) {
        float rate = annualRate / MONTHS_IN_A_YEAR / PERCENT;
        int periodInMonths = years * MONTHS_IN_A_YEAR;
        return principle * (rate * (Math.pow(1 + rate, periodInMonths)) / (Math.pow(1 + rate, periodInMonths) - 1));
    }

    private static void displayPaymentPlan(int principle, float annualRate, byte years) {
        System.out.println();
        System.out.println("Payment Plan:");
        System.out.println("-------------");
        for (int remainingPeriodInMonths = 1; remainingPeriodInMonths <= (years * MONTHS_IN_A_YEAR); remainingPeriodInMonths++  ){
            double balance = calcPaymentPlan(principle, annualRate, years,remainingPeriodInMonths);
            System.out.println(NumberFormat.getCurrencyInstance().format(balance));
        }
    }

    private static double calcPaymentPlan(int principle, float annualRate, byte years, int remainingPeriodInMonths) {
        float rate = annualRate / MONTHS_IN_A_YEAR / PERCENT;
        int periodInMonths = years * MONTHS_IN_A_YEAR;
        return principle * ((Math.pow(1 + rate, periodInMonths) - Math.pow(1 + rate, remainingPeriodInMonths)) / (Math.pow(1 + rate, periodInMonths) - 1));
    }

    public static void main(String[] args) {
        int principle = (int)getInput("Principle", 1000, 1000000);
        float annualRate = (float) getInput("Annual Rate",1, 30);
        byte years = (byte) getInput("Period in Years",1, 30);

        displayMortgage(principle, annualRate, years);

        displayPaymentPlan(principle, annualRate, years);
    }
}
