package MVC.Interface;


import MVC.Encapsulation.Encapsulation;

public interface Interfaces {

    int add(Encapsulation encapsulation);

    void sub(Encapsulation encapsulation);

}
